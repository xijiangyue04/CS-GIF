import matplotlib.pyplot as plt

# ==========================
# Data
# ==========================

# x-axis: number of input points
points = [1024, 512, 256, 128, 64]

# Replace with your experimental results
curvenet = [93.6, 92.5, 91.9, 90.6, 88.5]

ours = [93.8, 92.9, 92.5, 91.0, 88.6]


# ==========================
# Figure settings
# ==========================

plt.figure(figsize=(5, 4))

# CurveNet
plt.plot(
    points,
    curvenet,
    color='red',
    marker='*',
    markersize=9,
    linewidth=2,
    label='CurveNet'
)

# Ours
plt.plot(
    points,
    ours,
    color='blue',
    marker='o',
    markersize=6,
    linewidth=2,
    label='Ours'
)


# ==========================
# Axis
# ==========================

plt.xlabel(
    'Number of input points',
    fontsize=13,
    fontname='Times New Roman'
)

plt.ylabel(
    'Accuracy (%)',
    fontsize=13,
    fontname='Times New Roman'
)


# Reverse x-axis
plt.gca().invert_xaxis()


# ==========================
# Tick style
# ==========================

plt.xticks(
    points,
    fontsize=11,
    fontname='Times New Roman'
)

plt.yticks(
    fontsize=11,
    fontname='Times New Roman'
)


# ==========================
# Legend
# ==========================

plt.legend(
    fontsize=11,
    frameon=True,
    prop={'family':'Times New Roman'}
)


# ==========================
# Border style
# ==========================

ax = plt.gca()

for spine in ax.spines.values():
    spine.set_linewidth(1.2)


# No grid (SCI style)
plt.grid(False)


# Tight layout
plt.tight_layout()


# Save high-quality figures
plt.savefig(
    'CurveNet_vs_Ours_points.pdf',
    dpi=300,
    bbox_inches='tight'
)

plt.savefig(
    'CurveNet_vs_Ours_points.png',
    dpi=600,
    bbox_inches='tight'
)


plt.show()