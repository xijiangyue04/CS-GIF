
import torch
import torch.nn as nn
import torch.nn.functional as F
from time import time
import numpy as np

from .walk import Walk


def knn(x, k):
    k = k + 1
    inner = -2 * torch.matmul(x.transpose(2, 1), x)
    xx = torch.sum(x**2, dim=1, keepdim=True)
    pairwise_distance = -xx - inner - xx.transpose(2, 1)

    idx = pairwise_distance.topk(k=k, dim=-1)[1]  # (batch_size, num_points, k)
    return idx

def normal_knn(x, k):
    inner = -2 * torch.matmul(x.transpose(2, 1), x)
    xx = torch.sum(x**2, dim=1, keepdim=True)
    pairwise_distance = -xx - inner - xx.transpose(2, 1)

    idx = pairwise_distance.topk(k=k, dim=-1)[1]  # (batch_size, num_points, k)
    return idx

def pc_normalize(pc):
    l = pc.shape[0]
    centroid = np.mean(pc, axis=0)
    pc = pc - centroid
    m = np.max(np.sqrt(np.sum(pc**2, axis=1)))
    pc = pc / m
    return pc

def square_distance(src, dst):
    """
    Calculate Euclid distance between each two points.
    """
    B, N, _ = src.shape
    _, M, _ = dst.shape
    dist = -2 * torch.matmul(src, dst.permute(0, 2, 1))
    dist += torch.sum(src ** 2, -1).view(B, N, 1)
    dist += torch.sum(dst ** 2, -1).view(B, 1, M)
    return dist

def index_points(points, idx):
    """

    Input:
        points: input points data, [B, N, C]
        idx: sample index data, [B, S]
    Return:
        new_points:, indexed points data, [B, S, C]
    """
    device = points.device
    B = points.shape[0]
    view_shape = list(idx.shape)
    view_shape[1:] = [1] * (len(view_shape) - 1)
    repeat_shape = list(idx.shape)
    repeat_shape[0] = 1
    batch_indices = torch.arange(B, dtype=torch.long).to(device).view(view_shape).repeat(repeat_shape)
    new_points = points[batch_indices, idx, :]
    return new_points


def farthest_point_sample(xyz, npoint):
    """
    Input:
        xyz: pointcloud data, [B, N, 3]
        npoint: number of samples
    Return:
        centroids: sampled pointcloud index, [B, npoint]
    """
    device = xyz.device
    B, N, C = xyz.shape
    centroids = torch.zeros(B, npoint, dtype=torch.long).to(device)
    distance = torch.ones(B, N).to(device) * 1e10
    farthest = torch.randint(0, N, (B,), dtype=torch.long).to(device) * 0
    batch_indices = torch.arange(B, dtype=torch.long).to(device)
    for i in range(npoint):
        centroids[:, i] = farthest
        centroid = xyz[batch_indices, farthest, :].view(B, 1, 3)
        dist = torch.sum((xyz - centroid) ** 2, -1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = torch.max(distance, -1)[1]
    return centroids

def query_ball_point(radius, nsample, xyz, new_xyz):
    """
    Input:
        radius: local region radius
        nsample: max sample number in local region
        xyz: all points, [B, N, 3]
        new_xyz: query points, [B, S, 3]
    Return:
        group_idx: grouped points index, [B, S, nsample]
    """
    device = xyz.device
    B, N, C = xyz.shape
    _, S, _ = new_xyz.shape
    group_idx = torch.arange(N, dtype=torch.long).to(device).view(1, 1, N).repeat([B, S, 1])
    sqrdists = square_distance(new_xyz, xyz)
    group_idx[sqrdists > radius ** 2] = N
    group_idx = group_idx.sort(dim=-1)[0][:, :, :nsample]
    group_first = group_idx[:, :, 0].view(B, S, 1).repeat([1, 1, nsample])
    mask = group_idx == N
    group_idx[mask] = group_first[mask]
    return group_idx

def sample_and_group(npoint, radius, nsample, xyz, points, returnfps=False):
    """
    Input:
        npoint:
        radius:
        nsample:
        xyz: input points position data, [B, N, 3]
        points: input points data, [B, N, D]
    Return:
        new_xyz: sampled points position data, [B, npoint, nsample, 3]
        new_points: sampled points data, [B, npoint, nsample, 3+D]
    """
    new_xyz = index_points(xyz, farthest_point_sample(xyz, npoint))
    torch.cuda.empty_cache()

    idx = query_ball_point(radius, nsample, xyz, new_xyz)
    torch.cuda.empty_cache()

    new_points = index_points(points, idx)
    torch.cuda.empty_cache()

    if returnfps:
        return new_xyz, new_points, idx
    else:
        return new_xyz, new_points

class Attention_block(nn.Module):
    '''
    Used in attention U-Net.
    '''
    def __init__(self,F_g,F_l,F_int):
        super(Attention_block,self).__init__()
        self.W_g = nn.Sequential(
            nn.Conv1d(F_g, F_int, kernel_size=1,stride=1,padding=0,bias=True),
            nn.BatchNorm1d(F_int)
            )

        self.W_x = nn.Sequential(
            nn.Conv1d(F_l, F_int, kernel_size=1,stride=1,padding=0,bias=True),
            nn.BatchNorm1d(F_int)
        )

        self.psi = nn.Sequential(
            nn.Conv1d(F_int, 1, kernel_size=1,stride=1,padding=0,bias=True),
            nn.BatchNorm1d(1),
            nn.Sigmoid()
        )

    def forward(self,g,x):
        g1 = self.W_g(g)
        x1 = self.W_x(x)
        psi = F.leaky_relu(g1+x1, negative_slope=0.2)
        psi = self.psi(psi)

        return psi, 1. - psi


class LPFA(nn.Module):
    def __init__(self, in_channel, out_channel, k, mlp_num=2, initial=False):
        super(LPFA, self).__init__()
        self.k = k
        self.device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
        self.initial = initial

        if not initial:
            self.xyz2feature = nn.Sequential(
                        nn.Conv2d(9, in_channel, kernel_size=1, bias=False),
                        nn.BatchNorm2d(in_channel))

        self.mlp = []
        for _ in range(mlp_num):
            self.mlp.append(nn.Sequential(nn.Conv2d(in_channel, out_channel, 1, bias=False),
                                 nn.BatchNorm2d(out_channel),
                                 nn.LeakyReLU(0.2)))
            in_channel = out_channel
        self.mlp = nn.Sequential(*self.mlp)        

    def forward(self, x, xyz, idx=None):
        x = self.group_feature(x, xyz, idx)
        x = self.mlp(x)

        if self.initial:
            x = x.max(dim=-1, keepdim=False)[0]
        else:
            x = x.mean(dim=-1, keepdim=False)

        return x

    def group_feature(self, x, xyz, idx):
        batch_size, num_dims, num_points = x.size()

        if idx is None:
            idx = knn(xyz, k=self.k)[:,:,:self.k]  # (batch_size, num_points, k)

        idx_base = torch.arange(0, batch_size, device=self.device).view(-1, 1, 1) * num_points
        idx = idx + idx_base
        idx = idx.view(-1)

        xyz = xyz.transpose(2, 1).contiguous() # bs, n, 3
        point_feature = xyz.view(batch_size * num_points, -1)[idx, :]
        point_feature = point_feature.view(batch_size, num_points, self.k, -1)  # bs, n, k, 3
        points = xyz.view(batch_size, num_points, 1, 3).expand(-1, -1, self.k, -1)  # bs, n, k, 3

        point_feature = torch.cat((points, point_feature, point_feature - points),
                                dim=3).permute(0, 3, 1, 2).contiguous()

        if self.initial:
            return point_feature

        x = x.transpose(2, 1).contiguous() # bs, n, c
        feature = x.view(batch_size * num_points, -1)[idx, :]
        feature = feature.view(batch_size, num_points, self.k, num_dims)  #bs, n, k, c
        x = x.view(batch_size, num_points, 1, num_dims)
        feature = feature - x

        feature = feature.permute(0, 3, 1, 2).contiguous()
        point_feature = self.xyz2feature(point_feature)  #bs, c, n, k
        feature = F.leaky_relu(feature + point_feature, 0.2)
        return feature #bs, c, n, k


class LightLPFA(nn.Module):
    """
    Lightweight LPFA used for deep CIC blocks:
    - single neighbor mixer on [B, C, N, K]
    - K-pooling to local summary
    - pointwise residual bottleneck refinement on [B, C, N]
    """
    def __init__(self, in_channel, out_channel, k, initial=False, expand_ratio=2):
        super(LightLPFA, self).__init__()
        self.k = k
        self.initial = initial

        if not initial:
            self.xyz2feature = nn.Sequential(
                nn.Conv2d(9, in_channel, kernel_size=1, bias=False),
                nn.BatchNorm2d(in_channel)
            )

        self.neighbor_mixer = nn.Sequential(
            nn.Conv2d(in_channel if not initial else 9, out_channel, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channel),
            nn.LeakyReLU(0.2, inplace=True)
        )

        if not initial:
            hidden = max(out_channel , 16)
            self.pointwise_refine = nn.Sequential(
                nn.Conv1d(in_channel + out_channel, hidden, kernel_size=1, bias=False),
                nn.BatchNorm1d(hidden),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Conv1d(hidden, out_channel, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channel)
            )
            self.shortcut = nn.Identity() if in_channel == out_channel else nn.Sequential(
                nn.Conv1d(in_channel, out_channel, kernel_size=1, bias=False),
                nn.BatchNorm1d(out_channel)
            )



    def forward(self, x, xyz, idx=None):
        feat = self.group_feature(x, xyz, idx)       # [B, C, N, K] or [B, 9, N, K]
        feat = self.neighbor_mixer(feat)             # [B, Cout, N, K]

        if self.initial:
            return feat.max(dim=-1, keepdim=False)[0]

        pooled = feat.mean(dim=-1, keepdim=False)    # [B, Cout, N]
        fused = torch.cat([x, pooled], dim=1)        # [B, Cin+Cout, N]
        out = self.pointwise_refine(fused) + self.shortcut(x)
        return F.leaky_relu(out, negative_slope=0.2, inplace=True)

    def group_feature(self, x, xyz, idx):
        batch_size, num_dims, num_points = x.size()

        if idx is None:
            idx = knn(xyz, k=self.k)[:, :, :self.k]

        idx_base = torch.arange(0, batch_size, device=x.device).view(-1, 1, 1) * num_points
        idx = (idx + idx_base).view(-1)

        xyz = xyz.transpose(2, 1).contiguous()       # [B, N, 3]
        point_feature = xyz.view(batch_size * num_points, -1)[idx, :]
        point_feature = point_feature.view(batch_size, num_points, self.k, -1)  # [B, N, K, 3]
        points = xyz.view(batch_size, num_points, 1, 3).expand(-1, -1, self.k, -1)

        point_feature = torch.cat((points, point_feature, point_feature - points), dim=3)
        point_feature = point_feature.permute(0, 3, 1, 2).contiguous()          # [B, 9, N, K]

        if self.initial:
            return point_feature

        x_t = x.transpose(2, 1).contiguous()         # [B, N, C]
        feature = x_t.view(batch_size * num_points, -1)[idx, :]
        feature = feature.view(batch_size, num_points, self.k, num_dims)        # [B, N, K, C]
        x_center = x_t.view(batch_size, num_points, 1, num_dims)
        feature = (feature - x_center).permute(0, 3, 1, 2).contiguous()         # [B, C, N, K]

        point_feature = self.xyz2feature(point_feature)                           # [B, C, N, K]
        return F.leaky_relu(feature + point_feature, 0.2, inplace=True)


class PointNetFeaturePropagation(nn.Module):
    def __init__(self, in_channel, mlp, att=None):
        super(PointNetFeaturePropagation, self).__init__()
        self.mlp_convs = nn.ModuleList()
        self.mlp_bns = nn.ModuleList()
        last_channel = in_channel
        self.att = None
        if att is not None:
            self.att = Attention_block(F_g=att[0],F_l=att[1],F_int=att[2])
        
        for out_channel in mlp:
            self.mlp_convs.append(nn.Conv1d(last_channel, out_channel, 1))
            self.mlp_bns.append(nn.BatchNorm1d(out_channel))
            last_channel = out_channel

    def forward(self, xyz1, xyz2, points1, points2):
        """
        Input:
            xyz1: input points position data, [B, C, N]
            xyz2: sampled input points position data, [B, C, S], skipped xyz
            points1: input points data, [B, D, N]
            points2: input points data, [B, D, S], skipped features
        Return:
            new_points: upsampled points data, [B, D', N]
        """
        xyz1 = xyz1.permute(0, 2, 1)
        xyz2 = xyz2.permute(0, 2, 1)

        points2 = points2.permute(0, 2, 1)
        B, N, C = xyz1.shape
        _, S, _ = xyz2.shape

        if S == 1:
            interpolated_points = points2.repeat(1, N, 1)
        else:
            dists = square_distance(xyz1, xyz2)
            dists, idx = dists.sort(dim=-1)
            dists, idx = dists[:, :, :3], idx[:, :, :3]  # [B, N, 3]

            dist_recip = 1.0 / (dists + 1e-8)
            norm = torch.sum(dist_recip, dim=2, keepdim=True)
            weight = dist_recip / norm
            interpolated_points = torch.sum(index_points(points2, idx) * weight.view(B, N, 3, 1), dim=2)

        # skip attention
        if self.att is not None:
           psix, psig = self.att(interpolated_points.permute(0, 2, 1), points1)
           points1 = points1 * psix
           
        if points1 is not None:
            points1 = points1.permute(0, 2, 1)
            new_points = torch.cat([points1, interpolated_points], dim=-1)
        else:
            new_points = interpolated_points

        new_points = new_points.permute(0, 2, 1)

        for i, conv in enumerate(self.mlp_convs):
            bn = self.mlp_bns[i]
            new_points = F.leaky_relu(bn(conv(new_points)), 0.2)

        return new_points

def gather_neighbors(feat, idx):
    """
    feat: [B, C, N]
    idx:  [B, N, K]
    return: [B, C, N, K]
    """
    B, C, N = feat.shape
    K = idx.shape[-1]
    idx_expand = idx.unsqueeze(1).expand(-1, C, -1, -1)      # [B, C, N, K]
    feat_expand = feat.unsqueeze(-1).expand(-1, -1, -1, K)   # [B, C, N, K]
    return torch.gather(feat_expand, 2, idx_expand)

class ShellBranch(nn.Module):
    """
    Shell-style: KNN neighbors -> split into D groups -> maxpool per group -> conv fuse across D
    """
    def __init__(self, in_channels, out_channels, K, D=4, use_local=True):
        super().__init__()
        assert K % D == 0, f"K({K}) must be divisible by D({D})"
        self.K = K
        self.D = D
        self.s = K // D
        self.use_local = use_local

        if use_local:
            mid = max(8, in_channels // 2)
            self.local_mlp = nn.Sequential(
                nn.Conv2d(3, mid, 1, bias=False),
                nn.BatchNorm2d(mid),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Conv2d(mid, in_channels, 1, bias=False),
                nn.BatchNorm2d(in_channels),
                nn.LeakyReLU(0.2, inplace=True),
            )

        self.fuse = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(1, D), bias=False),
            nn.BatchNorm2d(out_channels),
            nn.LeakyReLU(0.2, inplace=True),
        )

    def forward(self, xyz, x, idx_knn):
        """
        xyz: [B, 3, N]
        x:   [B, C, N]  (这里你会传 conv1 后的 x0)
        idx_knn: [B, N, K+1] from knn() (包含 self)
        """
        idx = idx_knn[:, :, 1:self.K+1]               # [B, N, K] 去掉 self

        nbr_x = gather_neighbors(x, idx)              # [B, C, N, K]
        nbr_xyz = gather_neighbors(xyz, idx)          # [B, 3, N, K]
        delta = nbr_xyz - xyz.unsqueeze(-1)           # [B, 3, N, K]

        if self.use_local:
            local_feat = self.local_mlp(delta)        # [B, C, N, K]
            feat = nbr_x + local_feat
        else:
            feat = nbr_x

        B, C, N, K = feat.shape
        feat = feat.view(B, C, N, self.D, self.s).max(dim=-1)[0]  # [B, C, N, D]
        feat = self.fuse(feat).squeeze(-1)                        # [B, out, N]
        return feat




class CIC(nn.Module):
    def __init__(self, npoint, radius, k, in_channels, output_channels, bottleneck_ratio=2, mlp_num=2,
                 curve_config=None, light_lpfa=False, light_expand_ratio=2, shell_config=None):
        super(CIC, self).__init__()
        self.in_channels = in_channels
        self.output_channels = output_channels
        self.bottleneck_ratio = bottleneck_ratio
        self.radius = radius
        self.k = k
        self.npoint = npoint

        planes = in_channels // bottleneck_ratio

        self.use_curve = curve_config is not None
        if self.use_curve:
            self.curveaggregation = CurveAggregation(planes)
            self.curvegrouping = CurveGrouping(planes, k, curve_config[0], curve_config[1])

        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels,
                      planes,
                      kernel_size=1,
                      bias=False),
            nn.BatchNorm1d(in_channels // bottleneck_ratio),
            nn.LeakyReLU(negative_slope=0.2, inplace=True))

        self.conv2 = nn.Sequential(
            nn.Conv1d(planes, output_channels, kernel_size=1, bias=False),
            nn.BatchNorm1d(output_channels))

        if in_channels != output_channels:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_channels,
                          output_channels,
                          kernel_size=1,
                          bias=False),
                nn.BatchNorm1d(output_channels))

        self.relu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        self.maxpool = MaskedMaxPool(npoint, radius, k)

        if light_lpfa:
            self.lpfa = LightLPFA(planes, planes, k, initial=False, expand_ratio=light_expand_ratio)
        else:
            self.lpfa = LPFA(planes, planes, k, mlp_num=mlp_num, initial=False)

        self.use_shell = shell_config is not None
        if self.use_shell:
            D = shell_config.get("D", 4)
            use_local = shell_config.get("use_local", True)

            shell_out = shell_config.get("shell_out", planes // 2)

            self.shell_branch = ShellBranch(
                in_channels=planes, out_channels=shell_out, K=k, D=D, use_local=use_local
            )

            # concat 
            self.shell_fuse = nn.Sequential(
                nn.Conv1d(planes + shell_out, planes, 1, bias=False),
                nn.BatchNorm1d(planes),
                nn.LeakyReLU(0.2, inplace=True),
            )

    def forward(self, xyz, x):
 
        # max pool
        if xyz.size(-1) != self.npoint:
            xyz, x = self.maxpool(
                xyz.transpose(1, 2).contiguous(), x)
            xyz = xyz.transpose(1, 2)

        shortcut = x
        x0 = self.conv1(x)                      # [B, planes, N]
        idx = knn(xyz, self.k)                  # [B, N, k+1]

        # ---- curve branch (independent) ----
        x_curve = x0
        if self.use_curve:
            curves, flatten_curve_idxs = self.curvegrouping(x_curve, xyz, idx[:, :, 1:])
            x_curve = self.curveaggregation(x_curve, curves)
        else:
            flatten_curve_idxs = None

        x_curve = self.lpfa(x_curve, xyz, idx=idx[:, :, :self.k])  # [B, planes, N]

        # ---- shell branch (independent) ----
        if self.use_shell:
            x_shell = self.shell_branch(xyz, x0, idx)              # [B, shell_out, N]
            x_curve = self.shell_fuse(torch.cat([x_curve, x_shell], dim=1))  # -> [B, planes, N]

        x = self.conv2(x_curve)

        if self.in_channels != self.output_channels:
            shortcut = self.shortcut(shortcut)

        x = self.relu(x + shortcut)
        return xyz, x, flatten_curve_idxs


class CurveAggregation(nn.Module):
    def __init__(self, in_channel):
        super(CurveAggregation, self).__init__()
        self.in_channel = in_channel
        mid_feature = in_channel // 2

        # ===== cpe =====
        self.pos_enc = nn.Sequential(
            nn.Conv2d(1, in_channel, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channel),
            nn.LeakyReLU(0.2, inplace=True)
        )
        # ===== end =====

        self.conva = nn.Conv1d(in_channel,
                               mid_feature,
                               kernel_size=1,
                               bias=False)
        self.convb = nn.Conv1d(in_channel,
                               mid_feature,
                               kernel_size=1,
                               bias=False)
        self.convc = nn.Conv1d(in_channel,
                               mid_feature,
                               kernel_size=1,
                               bias=False)
        self.convn = nn.Conv1d(mid_feature,
                               mid_feature,
                               kernel_size=1,
                               bias=False)
        self.convl = nn.Conv1d(mid_feature,
                               mid_feature,
                               kernel_size=1,
                               bias=False)
        self.convd = nn.Sequential(
            nn.Conv1d(mid_feature * 2,
                      in_channel,
                      kernel_size=1,
                      bias=False),
            nn.BatchNorm1d(in_channel))
        self.line_conv_att = nn.Conv2d(in_channel,
                                       1,
                                       kernel_size=1,
                                       bias=False)

    def forward(self, x, curves):

            # ===== cpe =====
        c_l = curves.shape[-1]          
        bs  = curves.shape[0]
        c_n = curves.shape[2]

        pos = torch.arange(c_l, dtype=torch.float32, device=curves.device)
        pos = pos / (c_l - 1)
        pos = pos.view(1, 1, 1, c_l).expand(bs, 1, c_n, c_l)
        pos_feat = self.pos_enc(pos)                          # [bs, C, c_n, c_l]
        curves = curves + pos_feat
        # ===== end =====
        curves_att = self.line_conv_att(curves)  # bs, 1, c_n, c_l

        curver_inter = torch.sum(curves * F.softmax(curves_att, dim=-1), dim=-1)  #bs, c, c_n
        curves_intra = torch.sum(curves * F.softmax(curves_att, dim=-2), dim=-2)  #bs, c, c_l

        curver_inter = self.conva(curver_inter) # bs, mid, n
        curves_intra = self.convb(curves_intra) # bs, mid ,n

        x_logits = self.convc(x).transpose(1, 2).contiguous()
        x_inter = F.softmax(torch.bmm(x_logits, curver_inter), dim=-1) # bs, n, c_n
        x_intra = F.softmax(torch.bmm(x_logits, curves_intra), dim=-1) # bs, l, c_l
        

        curver_inter = self.convn(curver_inter).transpose(1, 2).contiguous()
        curves_intra = self.convl(curves_intra).transpose(1, 2).contiguous()

        x_inter = torch.bmm(x_inter, curver_inter)
        x_intra = torch.bmm(x_intra, curves_intra)

        curve_features = torch.cat((x_inter, x_intra),dim=-1).transpose(1, 2).contiguous()
        x = x + self.convd(curve_features)

        return F.leaky_relu(x, negative_slope=0.2)


class CurveGrouping(nn.Module):
    def __init__(self, in_channel, k, curve_num, curve_length):
        super(CurveGrouping, self).__init__()
        self.curve_num = curve_num
        self.curve_length = curve_length
        self.in_channel = in_channel
        self.k = k

        self.att = nn.Conv1d(in_channel, 1, kernel_size=1, bias=False)

        self.walk = Walk(in_channel, k, curve_num, curve_length)

    def forward(self, x, xyz, idx):
        # starting point selection in self attention style
        x_att = torch.sigmoid(self.att(x))
        x = x * x_att

        _, start_index = torch.topk(x_att,
                                    self.curve_num,
                                    dim=2,
                                    sorted=False)
        start_index = start_index.squeeze(1).unsqueeze(2)

        curves, flatten_curve_idxs = self.walk(xyz, x, idx, start_index)  #bs, c, c_n, c_l
        
        return curves, flatten_curve_idxs


class MaskedMaxPool(nn.Module):
    def __init__(self, npoint, radius, k):
        super(MaskedMaxPool, self).__init__()
        self.npoint = npoint
        self.radius = radius
        self.k = k

    def forward(self, xyz, features):
        sub_xyz, neighborhood_features = sample_and_group(self.npoint, self.radius, self.k, xyz, features.transpose(1,2))

        neighborhood_features = neighborhood_features.permute(0, 3, 1, 2).contiguous()
        sub_features = F.max_pool2d(
            neighborhood_features, kernel_size=[1, neighborhood_features.shape[3]]
        )  # bs, c, n, 1
        sub_features = torch.squeeze(sub_features, -1)  # bs, c, n
        return sub_xyz, sub_features
